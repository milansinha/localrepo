import java.util.*;  
class HashSetTest
{  
 public static void main(String args[])
{  
    HashSet<String> set=new HashSet<String>();  
  set.add("Sushil");  
  set.add("Rahul");  
  set.add("Sushil");  
  set.add("Rohan"); 
  Iterator<String> itr=set.iterator();  
  while(itr.hasNext())
{  
   System.out.println(itr.next());  
  }  
 }  
}  