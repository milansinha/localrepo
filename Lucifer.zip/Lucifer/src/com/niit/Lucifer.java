package com.niit;

public class Lucifer {
	public static void main(){
	int a=100;
	int b=200;
	          int c=300;
	}
}
