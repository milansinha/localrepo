import java.util.*; 



class Output { 



public static void main(String args[]) { 



ArrayList obj = new ArrayList(); 



obj.add("A"); 



obj.add(0, "B"); 



System.out.println(obj.size()); 



} 



} 