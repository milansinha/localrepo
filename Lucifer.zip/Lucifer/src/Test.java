public class test 

{ 

static void method(){} 

public static void main(String []args) throws Exception 

{ 

try 

{ 

method(); 

System.out.println("try"); 

} 

catch(Exception e) 

{ 

System.out.println("catch"); 

} 

finally 

{ 

System.out.println("finally"); 

} 

} 

} 
