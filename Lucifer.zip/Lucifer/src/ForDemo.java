class ForDemo 

{ 

public static void main(String arg[]) 

{ 

int i,j=0; 

for(i=1;i<10;i+=2) 

{ 

j=j+i; 

} 



System.out.println(j); 

} 



}