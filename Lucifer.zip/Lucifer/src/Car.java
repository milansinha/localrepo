class Car
{  
  void run()
{
System.out.println("running");
}  
}  
class Bmw extends Car
{  
  void run(){
System.out.println("running safely with 200km");
}  
  
  public static void main(String args[])
{  
    Car c = new Bmw();  
    c.run();  
  }  
}  