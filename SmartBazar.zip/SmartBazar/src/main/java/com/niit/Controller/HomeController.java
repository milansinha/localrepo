package com.niit.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller

public class HomeController {

	@RequestMapping("/")
	public ModelAndView showHome()
	{
		System.out.println("in controller");
		ModelAndView mv = new ModelAndView("home");
		return mv;
	}
	@RequestMapping("/login")
	public ModelAndView showLogin()
	{
		System.out.println("in controller");
		ModelAndView mv = new ModelAndView("Login");
		
		return mv;
	}
  @RequestMapping("/register")
public ModelAndView showregister()
{
	System.out.println("in controller");
	ModelAndView mv = new ModelAndView("register");
	
	return mv;
}
  @RequestMapping("/aboutus")
  public ModelAndView showaboutus()
  {
  	System.out.println("in controller");
  	ModelAndView mv = new ModelAndView("About us");
  	
  	return mv;
}
  @RequestMapping("/contactus")
  public ModelAndView showcontactus()
  {
  	System.out.println("in controller");
  	ModelAndView mv = new ModelAndView("contact");
  	
  	return mv;
}
  @RequestMapping("/adminhome")
  public ModelAndView showadminhome()
  {
  	System.out.println("in controller");
  	ModelAndView mv = new ModelAndView("adminhome");
  	
  	return mv;
}
}